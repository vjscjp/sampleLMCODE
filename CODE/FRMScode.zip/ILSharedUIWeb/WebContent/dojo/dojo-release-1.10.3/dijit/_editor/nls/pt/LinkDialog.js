//>>built
define("dijit/_editor/nls/pt/LinkDialog",({createLinkTitle:"Propriedades de Link",insertImageTitle:"Propriedades de Imagem",url:"URL:",text:"Descrição:",target:"Destino:",set:"Configurar",currentWindow:"Janela Atual",parentWindow:"Janela Pai",topWindow:"Primeira Janela",newWindow:"Nova Janela"}));
