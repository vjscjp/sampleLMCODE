//>>built
define("dijit/_editor/nls/el/LinkDialog",({createLinkTitle:"Ιδιότητες σύνδεσης",insertImageTitle:"Ιδιότητες εικόνας",url:"Διεύθυνση URL:",text:"Περιγραφή:",target:"Προορισμός:",set:"Ορισμός",currentWindow:"Τρέχον παράθυρο",parentWindow:"Γονικό παράθυρο",topWindow:"Παράθυρο σε πρώτο πλάνο",newWindow:"Νέο παράθυρο"}));
