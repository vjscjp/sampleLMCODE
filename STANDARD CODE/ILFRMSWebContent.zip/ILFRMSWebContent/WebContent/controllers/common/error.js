//Predefined tokens
/*global define : true*/
/*global console : true*/
/*global setTimeout : true*/



define(["dojo/dom", "dojo/on", "dojo/_base/lang", "dojo/dom-style", "controllers/widgets/functions.js", "dojo/promise/all"
        ],
        function (dom, on, lang, domStyle, Functions, all) {
        "use strict";
        // Functions.js helper Widget
        var Function = new Functions();
        return {
            init: function () {
                
            },
            beforeActivate: function (previousView, data) {
                
            },
            afterActivate: function (previousView, data) {
            	
            }

        };
    }
    );